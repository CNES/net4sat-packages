#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# OpenBACH is a generic testbed able to control/configure multiple
# network/physical entities (under test) and collect data from them. It is
# composed of an Auditorium (HMIs), a Controller, a Collector and multiple
# Agents (one for each network entity that wants to be tested).
#
#
# Copyright © 2016-2023 CNES
#
#
# This file is part of the OpenBACH testbed.
#
#
# OpenBACH is a free software : you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# this program. If not, see http://www.gnu.org/licenses/.


"""Call the openbach-function list_scenario_instance"""


__author__ = 'Viveris Technologies'
__credits__ = '''Contributors:
 * Adrien THIBAUD <adrien.thibaud@toulouse.viveris.com>
 * Mathias ETTINGER <mathias.ettinger@toulouse.viveris.com>
'''


from auditorium_scripts.frontend import FrontendBase


class ListScenarioInstances(FrontendBase):
    def __init__(self):
        super().__init__('OpenBACH — List Instances of a Scenario')
        self.parser.add_argument('project_name', help='name of the project')
        self.parser.add_argument(
                '-s', '--scenario-name', '--scenario',
                help='name of the scenario whose instances should be listed'
                '. Defaults to all scenarios.')
        self.parser.add_argument(
                '-q', '--quiet', action='store_true',
                help='Limit the amount of information returned to the minimum')
        self.parser.add_argument(
                '-l', '--limit', type=int,
                help='Limit the amount of scenario instances returned')

    def execute(self, show_response_content=True):
        scenario = self.args.scenario_name
        project = self.args.project_name
        params = {}
        if self.args.quiet:
            params['quiet'] = True
        if self.args.limit:
            params['limit'] = self.args.limit

        if scenario is None:
            route = 'project/{}/scenario_instance/'.format(project)
        else:
            route = 'project/{}/scenario/{}/scenario_instance/'.format(project, scenario)

        return self.request('GET', route, show_response_content=show_response_content, **params)


if __name__ == '__main__':
    ListScenarioInstances.autorun()
