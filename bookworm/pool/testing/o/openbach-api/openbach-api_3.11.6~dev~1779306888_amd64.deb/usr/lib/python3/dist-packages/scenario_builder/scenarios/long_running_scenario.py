#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#   OpenBACH is a generic testbed able to control/configure multiple
#   network/physical entities (under test) and collect data from them. It is
#   composed of an Auditorium (HMIs), a Controller, a Collector and multiple
#   Agents (one for each network entity that wants to be tested).
#
#
#   Copyright © 2016-2023 CNES
#
#
#   This file is part of the OpenBACH testbed.
#
#
#   OpenBACH is a free software : you can redistribute it and/or modify it under
#   the terms of the GNU General Public License as published by the Free Software
#   Foundation, either version 3 of the License, or (at your option) any later
#   version.
#
#   This program is distributed in the hope that it will be useful, but WITHOUT
#   ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
#   FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
#   details.
#
#   You should have received a copy of the GNU General Public License along with
#   this program. If not, see http://www.gnu.org/licenses/.


from scenario_builder import Scenario, Condition, Operand


SCENARIO_NAME = 'long_running_link_test'
SCENARIO_DESCRIPTION = """Scenario that performs periodic speedtests
and aggregates results from time to time.
"""


def post_processing(entity, agent_name):
    scenario = Scenario('long_running_postprocessing', 'Scenario aggregating speedtests results from the past 1 week to 3 months')
    f = scenario.add_function('start_job_instance')
    f.configure('summary_time_period', entity, agent=agent_name, job='speedtest', statistic='dl_throughput', reference=1000000, timespan=7)
    f = scenario.add_function('start_job_instance')
    f.configure('summary_agent_comparison', entity, agents=[agent_name], job='speedtest', statistic='dl_throughput', timespan=7)
    f = scenario.add_function('start_job_instance')
    f.configure('summary_time_period', entity, agent=agent_name, job='speedtest', statistic='dl_throughput', reference=1000000, timespan=30)
    f = scenario.add_function('start_job_instance')
    f.configure('summary_agent_comparison', entity, agents=[agent_name], job='speedtest', statistic='dl_throughput', timespan=30)
    f = scenario.add_function('start_job_instance')
    f.configure('summary_time_period', entity, agent=agent_name, job='speedtest', statistic='dl_throughput', reference=1000000, timespan=90)
    f = scenario.add_function('start_job_instance')
    f.configure('summary_agent_comparison', entity, agents=[agent_name], job='speedtest', statistic='dl_throughput', timespan=90)
    return scenario


def build(
        speedtest_entity, interface, server_id=53170,
        post_processing_entity=None, speedtest_agent_name=None,
        scenario_name=SCENARIO_NAME):
    scenario = Scenario(scenario_name, SCENARIO_DESCRIPTION)
    scenario.add_argument('loop_interval', 'time between tests')
    if post_processing_entity is not None:
        scenario.add_argument('coalesce_delay', 'execute post-processing jobs at')

    tests = scenario.add_function('start_job_instance')
    tests.configure('speedtest', speedtest_entity, server_id=server_id, interface=interface)
    tests.ignore_on_fail()

    reboot = scenario.add_function('reboot')
    reboot.configure(speedtest_entity, None)

    if post_processing_entity is not None:
        f = scenario.add_function('start_scenario_instance')
        f.configure(post_processing(post_processing_entity, speedtest_agent_name))
        f.ignore_on_fail()

        post_process = scenario.add_function('if')
        post_process.configure(Condition('=', Operand('elapsed', duration='$coalesce_delay'), Operand('value', value='True')))
        post_process.configure_if_true(f)

    f = scenario.add_function('if', wait_finished=[tests])
    f.configure(Condition('=', Operand('status', function_id=tests), Operand('value', value='NR')), should_wait=True)
    if post_processing_entity is not None:
        f.configure_if_true(post_process)
    f.configure_if_false(reboot)

    loop = scenario.add_function('while')
    loop.configure(Condition('=', Operand('value', value='True'), Operand('value', value='True')), interval='$loop_interval', should_wait=True)
    loop.configure_while_body(tests, f)

    return scenario
